HTML Runner — Recovery Code সংস্করণ

এটি Android Studio source project; APK নয়।

ফিচার:
1. প্রথমবার ৪–৬ সংখ্যার PIN তৈরি।
2. প্রথম PIN তৈরির পর ১২ অক্ষরের Recovery Code দেখায়।
3. Recovery Code ভুলে না যাওয়ার জন্য ব্যবহারকারীকে নিরাপদ জায়গায় সংরক্ষণ করতে হবে।
4. PIN ভুলে গেলে Recovery Code যাচাই করে নতুন PIN সেট করা যায়।
5. PIN রিসেট বা পরিবর্তনের পর পুরোনো Recovery Code বাতিল হয় এবং নতুন Recovery Code দেখায়।
6. HTML ফাইল নির্বাচন করে চালানো যায়; নতুন HTML দিলে active_app.html প্রতিস্থাপিত হয়।
7. WebView JavaScript এবং DOM Storage চালু।

গুরুত্বপূর্ণ:
- Recovery Code হারালে এই স্থানীয় ব্যবস্থায় PIN পুনরুদ্ধার করা যাবে না।
- অ্যাপের ডেটা/অ্যাপ আনইনস্টল করলে PIN, Recovery Code hash এবং সংরক্ষিত HTML মুছে যেতে পারে।
- Recovery Code কাগজে বা নিরাপদ পাসওয়ার্ড ম্যানেজারে সংরক্ষণ করুন।
- এই প্রজেক্টে PIN/Recovery Code-এর hash রাখা হয়; আসল PIN বা Recovery Code সরাসরি রাখা হয় না।
- এটি Android Studio-তে খুলে Gradle Sync করে Build > Build APK(s) করতে হবে।
- Android Studio-তে JDK 17 এবং Android SDK 35 প্রয়োজন।
- একক HTML ফাইলের ভেতরে CSS/JS/image embed করা না থাকলে সেগুলো আলাদা করে লোড নাও হতে পারে।
