package com.example.htmlrunner;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.*;
import android.view.View;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import java.io.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_HTML = 41;
    private SharedPreferences prefs;
    private LinearLayout root;
    private WebView webView;
    private String pendingRecoveryCode = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("runner_secure", MODE_PRIVATE);
        if (!prefs.getBoolean("pin_ready", false)) showCreatePin();
        else showLogin();
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(Color.WHITE);
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.BLACK);
        heading.setTextSize(25);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setPadding(0, 0, 0, 22);
        root.addView(heading);
        setContentView(root);
    }

    private TextView note(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.DKGRAY); t.setTextSize(15);
        t.setPadding(0, 4, 0, 16);
        root.addView(t); return t;
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setInputType(type);
        e.setTextSize(17);
        root.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private void btn(String text, Runnable action) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.BLACK));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 12; root.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    private void showCreatePin() {
        base("HTML Runner");
        note("প্রথমবার ব্যবহারের জন্য ৪–৬ সংখ্যার PIN তৈরি করুন।");
        EditText p1 = field("নতুন PIN", 2);
        EditText p2 = field("PIN আবার লিখুন", 2);
        btn("PIN তৈরি করুন", () -> {
            String a = p1.getText().toString(), b = p2.getText().toString();
            if (!validPin(a)) { msg("PIN অবশ্যই ৪–৬ সংখ্যার হতে হবে।"); return; }
            if (!a.equals(b)) { msg("দুইটি PIN মিলেনি।"); return; }
            String code = makeRecoveryCode();
            saveCredentials(a, code);
            showRecoveryCode(code, true);
        });
    }

    private void showRecoveryCode(String code, boolean firstTime) {
        base("আপনার Recovery Code");
        note("এই কোডটি লিখে নিরাপদ জায়গায় সংরক্ষণ করুন। PIN ভুলে গেলে এই কোড দিয়েই নতুন PIN সেট করতে পারবেন।");
        TextView c = new TextView(this);
        c.setText(code); c.setTextSize(25); c.setTypeface(null, Typeface.BOLD);
        c.setTextColor(Color.BLACK); c.setBackgroundColor(0xFFEFEFEF);
        c.setPadding(16, 20, 16, 20); c.setTextIsSelectable(true);
        root.addView(c);
        btn("কোড কপি করুন", () -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Recovery Code", code));
            msg("Recovery Code কপি হয়েছে।");
        });
        btn(firstTime ? "সংরক্ষণ করেছি, এগিয়ে যান" : "নতুন কোড সংরক্ষণ করেছি", () -> showLogin());
    }

    private void showLogin() {
        base("HTML Runner");
        note("আপনার PIN দিয়ে প্রবেশ করুন।");
        EditText pin = field("PIN লিখুন", 2);
        btn("প্রবেশ করুন", () -> {
            String savedSalt = prefs.getString("pin_salt", "");
            if (hash(savedSalt + pin.getText().toString()).equals(prefs.getString("pin_hash", ""))) showHome();
            else msg("ভুল PIN। আবার চেষ্টা করুন।");
        });
        btn("PIN ভুলে গেছেন? Recovery Code দিন", () -> showRecoveryEntry());
    }

    private void showRecoveryEntry() {
        base("Recovery Code");
        note("আপনার সংরক্ষিত Recovery Code লিখুন। কোড সঠিক হলে নতুন PIN সেট করতে পারবেন।");
        EditText code = field("Recovery Code", 1);
        btn("কোড যাচাই করুন", () -> {
            String normalized = normalize(code.getText().toString());
            String salt = prefs.getString("recovery_salt", "");
            if (!normalized.isEmpty() && hash(salt + normalized).equals(prefs.getString("recovery_hash", ""))) {
                showResetPin();
            } else msg("Recovery Code সঠিক নয়।");
        });
        btn("ফিরে যান", () -> showLogin());
    }

    private void showResetPin() {
        base("নতুন PIN সেট করুন");
        note("Recovery Code সঠিক হয়েছে। এখন নতুন ৪–৬ সংখ্যার PIN দিন।");
        EditText p1 = field("নতুন PIN", 2);
        EditText p2 = field("নতুন PIN আবার লিখুন", 2);
        btn("নতুন PIN সংরক্ষণ করুন", () -> {
            String a = p1.getText().toString(), b = p2.getText().toString();
            if (!validPin(a)) { msg("PIN অবশ্যই ৪–৬ সংখ্যার হতে হবে।"); return; }
            if (!a.equals(b)) { msg("দুইটি PIN মিলেনি।"); return; }
            String newCode = makeRecoveryCode();
            saveCredentials(a, newCode);
            showRecoveryCode(newCode, false);
        });
    }

    private void saveCredentials(String pin, String code) {
        String ps = randomHex(16), rs = randomHex(16);
        prefs.edit().putBoolean("pin_ready", true)
            .putString("pin_salt", ps).putString("pin_hash", hash(ps + pin))
            .putString("recovery_salt", rs).putString("recovery_hash", hash(rs + normalize(code)))
            .apply();
    }

    private void showHome() {
        base("HTML Runner");
        note("একটি HTML ফাইল নির্বাচন করুন। নতুন ফাইল দিলে আগের HTML ফাইলটি প্রতিস্থাপিত হবে।");
        btn("HTML ফাইল নির্বাচন করুন", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/html");
            startActivityForResult(i, PICK_HTML);
        });
        btn("অ্যাপ চালু করুন", () -> openHtml());
        btn("PIN পরিবর্তন", () -> showChangePin());
        btn("লক করুন", () -> showLogin());
    }

    private void showChangePin() {
        base("PIN পরিবর্তন");
        EditText old = field("বর্তমান PIN", 2);
        EditText p1 = field("নতুন PIN", 2);
        EditText p2 = field("নতুন PIN আবার লিখুন", 2);
        btn("PIN পরিবর্তন করুন", () -> {
            String salt = prefs.getString("pin_salt", "");
            if (!hash(salt + old.getText().toString()).equals(prefs.getString("pin_hash", ""))) { msg("বর্তমান PIN সঠিক নয়।"); return; }
            String a=p1.getText().toString(), b=p2.getText().toString();
            if (!validPin(a) || !a.equals(b)) { msg("নতুন PIN সঠিকভাবে দিন।"); return; }
            String code=makeRecoveryCode(); saveCredentials(a, code); showRecoveryCode(code, false);
        });
        btn("ফিরে যান", () -> showHome());
    }

    private void openHtml() {
        File f = new File(getFilesDir(), "active_app.html");
        if (!f.exists()) { msg("আগে একটি HTML ফাইল নির্বাচন করুন।"); return; }
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file://" + f.getAbsolutePath());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_HTML && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(new File(getFilesDir(), "active_app.html"))) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                msg("HTML ফাইল সংরক্ষণ হয়েছে।");
                showHome();
            } catch (Exception e) { msg("ফাইল খোলা যায়নি: " + e.getMessage()); }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else { webView = null; showHome(); }
    }

    private boolean validPin(String p) { return p.matches("[0-9]{4,6}"); }
    private String makeRecoveryCode() {
        final String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        SecureRandom r = new SecureRandom(); StringBuilder b = new StringBuilder();
        for (int i=0;i<12;i++) { if (i>0 && i%4==0) b.append('-'); b.append(chars.charAt(r.nextInt(chars.length()))); }
        return b.toString();
    }
    private String normalize(String s) { return s.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", ""); }
    private String randomHex(int n) {
        byte[] b = new byte[n]; new SecureRandom().nextBytes(b); StringBuilder s=new StringBuilder();
        for(byte x:b) s.append(String.format(Locale.US,"%02x",x)); return s.toString();
    }
    private String hash(String s) {
        try {
            byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
            StringBuilder b=new StringBuilder(); for(byte x:d)b.append(String.format(Locale.US,"%02x",x)); return b.toString();
        } catch(Exception e) { return ""; }
    }
    private void msg(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
